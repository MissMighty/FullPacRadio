FULL PAC — BATTLE + VOTE PAGE PATCH

Files:
- index.html
- battle.html
- vote.html
- FullPAC_Battle_Host.html

Public flow:
index.html -> battle.html -> vote.html

Both public pages read the existing Firebase battle/live, battle/votes,
battle/timer, battle/settings and battle/stats data.

Launch baseline:
- viewers 0
- votes 0
- no active battle until Host Control starts one

Important for production competition integrity:
The current public vote submission uses the existing Firebase client workflow.
Before using voting for prizes, rankings, or a consequential competition,
add Firebase Authentication and restrictive database rules so repeat/automated
votes cannot be trusted merely because the page UI disables a second click.
